@echo off
echo ==========================================
echo Installing Chromium for Playwright (.NET)
echo ==========================================

cd /d "%~dp0"

if not exist "%~dp0playwright.ps1" (
    echo ERROR: playwright.ps1 not found in this folder!
    exit /b 1
)

echo Running Playwright installer...

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0playwright.ps1" install chromium

echo.
echo ==========================================
echo Chromium installation completed!
echo ==========================================